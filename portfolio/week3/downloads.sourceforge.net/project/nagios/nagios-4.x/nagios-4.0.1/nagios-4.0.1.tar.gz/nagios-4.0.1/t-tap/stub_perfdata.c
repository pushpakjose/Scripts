int update_host_performance_data(host *hst) {}
